const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(__dirname)); // Serve HTML/CSS/JS

// =======================
// DATABASE CONNECTION
// =======================
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'Macrochef'
});

db.connect((err) => {
    if (err) throw err;
    console.log('✅ Connected to XAMPP MySQL!');
});


// =======================
// AUTH ROUTES
// =======================

// LOGIN
app.post('/login', (req, res) => {
    const user = req.body.username;
    const pass = req.body.password;

    const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
    db.query(sql, [user, pass], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            res.redirect('/dashboard'); // go to dashboard
        } else {
            res.send("Invalid Username or Password. <a href='login.html'>Try again</a>");
        }
    });
});

// REGISTER
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const sql = "INSERT INTO users (username, password) VALUES (?, ?)";
    
    db.query(sql, [username, password], (err) => {
        if (err) return res.send("Error: Username might be taken.");
        res.send("<h1>Registration Successful!</h1><a href='login.html'>Login Now</a>");
    });
});

// Serve Register Page
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'register.html'));
});

// Serve Dashboard Page
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});


// =======================
// RECIPES API
// =======================

// Get all recipes (for dashboard list)
app.get('/api/recipes', (req, res) => {
    const sql = `
        SELECT recipe_name, category, calories, protein_g, carbs_g, fat_g
        FROM mock_data
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});


// Search recipe by name (nutrition analysis box)
app.get('/api/recipes/search', (req, res) => {
    const recipeName = req.query.name;
    const category = req.query.category;

    const sql = `
        SELECT recipe_name, category, protein_g, carbs_g, fat_g
        FROM mock_data
        WHERE recipe_name LIKE ? AND category = ?
    `;

    db.query(sql, [`%${recipeName}%`, category], (err, results) => {
        if (err) return res.status(500).json(err);

        const analyzedResults = results.map(r => {
            const calories = (r.protein_g * 4) + (r.carbs_g * 4) + (r.fat_g * 9);
            return { ...r, calories };
        });

        res.json(analyzedResults);
    });
});




app.get('/api/recipes', (req, res) => {
    const sql = `
        SELECT id, recipe_name, category, calories, protein_g, carbs_g, fat_g
        FROM mock_data
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json(err);
        res.json(results);
    });
});


// =======================
// ADMIN ROUTES
// =======================

// Add Recipe
app.post('/api/admin/add', (req, res) => {
    const { name, category, calories, protein, carbs, fat } = req.body;

    const sql = `INSERT INTO mock_data (recipe_name, category, calories, protein_g, carbs_g, fat_g)
                 VALUES (?, ?, ?, ?, ?, ?)`;

    db.query(sql, [name, category, calories, protein, carbs, fat], err => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Recipe added" });
    });
});

// Delete Recipe
app.delete('/api/admin/delete/:id', (req, res) => {
    db.query("DELETE FROM mock_data WHERE id = ?", [req.params.id], err => {
        if (err) return res.status(500).json(err);
        res.json({ message: "Recipe deleted" });
    });
});


// =======================
// START SERVER
// =======================
app.listen(3000, () => {
    console.log('🚀 Server running at http://localhost:3000');
});



